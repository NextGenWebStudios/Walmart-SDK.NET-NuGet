﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walmart.SDK.Entities
{
    public abstract class WalmartEntity
    {
    }
}
